let tileSize = 60;

let rows = 3;

let cols = 5;

let tiles = [];

let money = 0;

let growthRate = 0.01;

let transportCooldown = 1;

let cityStock = 0;

let truckX = 0;

let truckMoving = false;

let truckSentCount = 0;

let plantValue = 10;

let showShop = false;

let showWeatherHelp = false;

let upgrades = { autoPlant: false, autoTransport: false, expandCount: 0, valueMultiplier: 1 };

let upgradePrices = { value: 1000, expand: 1500, autoPlant: 2000, autoTransport: 3000 };

let upgradeLimits = { expand: 1 };

let progress = 0;

let progressGoal = 1000;

let gameState = "start";

let storyStep = 0;

let creditsStep = 0;

let drought = false;

let flood = false;

let weatherEventDuration = 0;

let weatherMessage = "";

let nextWeatherEventTimer = 1500;

let bgMusic;

let plantSound;

let coinSound;

let showPCWarning = true;

function preload() {

  soundFormats('mp3');

  bgMusic = loadSound('fazendinha.mp3');

  plantSound = loadSound('plantando.mp3');

  coinSound = loadSound('moeda.mp3');

}

function setup() {

  createCanvas(600, 550);

  generateTiles();

  textFont('Arial');

  truckX = width + 80;

  if (bgMusic && !bgMusic.isPlaying()) {

    bgMusic.setLoop(true);

    bgMusic.setVolume(0.5);

    bgMusic.play();

  }

}

function draw() {

  drawTexturedBackground();

  if (showPCWarning && gameState === "start") drawPCWarning();

  if (showWeatherHelp) { drawWeatherHelp(); return; }

  if (gameState === "start") { drawStartScreen(); return; }

  if (gameState === "story") { drawStoryScreen(); return; }

  if (gameState === "victory") { drawVictoryScreen(); return; }

  if (gameState === "credits") { drawCreditsScreen(); return; }

  if (gameState === "references") { drawReferencesScreen(); return; }

  handleWeatherEvents();

  drawRoad();

  for (let tile of tiles) {

    tile.update();

    tile.show();

  }

  if (truckMoving) drawTruck();

  drawMissionBar();

  drawHUD();

  drawMiniFarm();

  drawShopButton();

  drawHelpButton();

  if (showShop) drawShop();

  if (transportCooldown > 0) transportCooldown--;

  if (upgrades.autoPlant) autoPlant();

  if (upgrades.autoTransport && countReadyCrops() >= 10 && !truckMoving) startTruck();

  if (progress >= progressGoal && gameState !== "victory") {

    gameState = "victory";

    storyStep = 0;

  }

}

function drawPCWarning() {

  fill(150, 75, 0); // Marrom forte

  stroke(0);

  rect(20, 10, width - 40, 30, 5);

  noStroke();

  fill(255);

  textSize(14);

  textAlign(CENTER, CENTER);

  text("⚠️ Versão somente para computador", width / 2, 25);

}

function drawTexturedBackground() {

  background(172, 142, 104);

  noStroke();

  for (let i = 0; i < 100; i++) {

    fill(160 + random(-20, 20), 130 + random(-10, 10), 100 + random(-10, 10), 30);

    ellipse(random(width), random(height), random(3, 10));

  }

}

function drawStartScreen() {

  fill(0);

  textSize(20);

  textAlign(CENTER, CENTER);

  text("🌾 Da Terra à Cidade 🌆", width / 2, 60);

  textSize(16);

  text("Desafios de colher e plantar do Produtor Rural", width / 2, 100);

  text("no Litoral do Paraná", width / 2, 120);

  textSize(14);

  text("Herdaste uma pequena fazenda de seu avô,", width / 2, 160);

  text("um canto tranquilo, mas cheio de potencial.", width / 2, 180);

  text("Agora, com trabalho duro e esperança,", width / 2, 200);

  text("sua missão é alimentar a cidade!", width / 2, 220);

  text("Clique para começar sua jornada!", width / 2, 260);

  text("Controles: Q-Loja | W-Parar AutoTransporte | A-Transporte Manual | Z-Ajuda clima", width / 2, 300);

  text("⚠️ Fique atento aos eventos climáticos!", width / 2, 330);

}

function drawStoryScreen() {

  background(230, 255, 230);

  fill(0);

  textSize(14);

  textAlign(LEFT, TOP);

  text(

    "O sol nasce, o campo te chama.\n\nNo litoral do Paraná, entre montanhas e o mar, produtores semeiam sonhos, colhem conquistas e levam alimento e esperança até a cidade grande.\n\nCada semente plantada é um passo a um futuro sustentável, valorizando a agricultura familiar, a preservação da Mata Atlântica e a tradição das comunidades locais.\n\nGustavo Spanholi",

    50, 80, 500, 300

  );

  textAlign(CENTER);

  text("Clique para começar o jogo!", width / 2, 470);

}

function generateTiles() {

  tiles = [];

  for (let y = 0; y < rows; y++)

    for (let x = 0; x < cols; x++)

      tiles.push(new Tile(x * tileSize + 20, y * tileSize + 80));

}

function Tile(x, y) {

  this.x = x;

  this.y = y;

  this.state = "empty";

  this.growth = 0;

  this.update = function () {

    if (this.state === "growing") {

      let eff = growthRate * (drought ? 0.3 : 1);

      this.growth += eff;

      if (this.growth >= 1) this.state = random() < 0.1 ? "praga" : "ready";

    }

  };

  this.show = function () {

    stroke(0);

    fill(150, 100, 50);

    rect(this.x, this.y, tileSize - 5, tileSize - 5);

    textSize(20);

    textAlign(CENTER, CENTER);

    if (this.state === "growing") text("🌱", this.x + tileSize / 2, this.y + tileSize / 2);

    else if (this.state === "ready") text("🌽", this.x + tileSize / 2, this.y + tileSize / 2);

    else if (this.state === "praga") text("🐛", this.x + tileSize / 2, this.y + tileSize / 2);

  };

  this.clicked = function (mx, my) {

    if (flood) return false;

    if (mx > this.x && mx < this.x + tileSize - 5 && my > this.y && my < this.y + tileSize - 5) {

      if (this.state === "empty") {

        this.state = "growing";

        this.growth = 0;

        if (plantSound) plantSound.play();

      } else if (this.state === "ready") {

        this.state = "empty";

        this.growth = 0;

        money += plantValue * upgrades.valueMultiplier;

        progress++;

      } else if (this.state === "praga") this.state = "empty";

      return true;

    }

    return false;

  };

}

function startTruck() {

  truckMoving = true;

  truckX = width + 80;

  truckSentCount = 0;

  for (let t of tiles) {

    if (t.state === "ready" && truckSentCount < 10) {

      t.state = "empty";

      t.growth = 0;

      truckSentCount++;

    }

  }

  transportCooldown = 100;

}

function drawTruck() {

  truckX -= 3;

  textSize(30);

  text("🚚", truckX, height - 150);

  if (truckX < -60) {

    truckMoving = false;

    cityStock += truckSentCount;

    money += truckSentCount * plantValue * upgrades.valueMultiplier / 2;

    progress += truckSentCount;

    if (coinSound) coinSound.play();

  }

}

function drawRoad() {

  fill(100);

  rect(0, height - 160, width, 40);

  stroke(255);

  strokeWeight(2);

  for (let i = 0; i < width; i += 30) line(i, height - 140, i + 15, height - 140);

  noStroke();

}

function drawMissionBar() {

  fill(255);

  stroke(0);

  rect(10, height - 100, width - 20, 30, 8);

  noStroke();

  fill(0);

  textSize(14);

  textAlign(CENTER, CENTER);

  text("🌾 Envie " + progress + "/" + progressGoal + " colheitas para vencer", width / 2, height - 85);

}

function drawHUD() {

  fill(0);

  textSize(16);

  textAlign(RIGHT, TOP);

  text("Dinheiro: R$ " + money, width - 10, 60);

}

function drawMiniFarm() {

  fill(120, 180, 90);

  rect(0, height - 60, width, 60);

  textSize(22);

  textAlign(LEFT, CENTER);

  let baseY = height - 30;

  text("🐄", 150, baseY);

  text("🌻🌻", 200, baseY);

  text("🌿🌿", 280, baseY);

  text("🚜", 360, baseY);

}

function drawShopButton() {

  fill(255, 200, 0);

  stroke(0);

  rect(20, height - 80, 80, 30, 5);

  noStroke();

  fill(0);

  textSize(12);

  textAlign(CENTER, CENTER);

  text("🛒 Loja", 60, height - 65);

}

function drawHelpButton() {

  fill(150, 200, 255);

  stroke(0);

  rect(20, height - 40, 80, 30, 5);

  noStroke();

  fill(0);

  textSize(12);

  textAlign(CENTER, CENTER);

  text("☁️ Clima", 60, height - 25);

}

function drawShop() {

  fill(255);

  stroke(0);

  rect(100, 70, 400, 350, 10);

  noStroke();

  fill(0);

  textSize(16);

  textAlign(CENTER, TOP);

  text("🛒 Loja da Fazenda", 300, 80);

  let items = [

    { name: "Aumentar Valor", price: upgradePrices.value, y: 120 },

    { name: (upgrades.expandCount >= upgradeLimits.expand ? "Expandir Plantação (LIMITADO)" : "Expandir Plantação"), price: upgradePrices.expand, y: 160 },

    { name: "Auto Plantar", price: upgradePrices.autoPlant, y: 200 },

    { name: "Auto Transportar", price: upgradePrices.autoTransport, y: 240 }

  ];

  for (let item of items) {

    text(item.name + " - R$" + item.price, 300, item.y);

  }

  // Botão Sair da Loja (fica em cima do botão Loja da tela principal)

  fill(255, 100, 100);

  stroke(0);

  rect(20, height - 80, 80, 30, 5);

  noStroke();

  fill(0);

  textAlign(CENTER, CENTER);

  text("❌ Sair", 60, height - 65);

}

function handleShopClick(mx, my) {

  let yOffsets = [120, 160, 200, 240];

  for (let i = 0; i < 4; i++) {

    if (mx > 150 && mx < 450 && my > yOffsets[i] && my < yOffsets[i] + 20) {

      [

        () => { if (money >= upgradePrices.value) { money -= upgradePrices.value; upgrades.valueMultiplier++; upgradePrices.value *= 2; } },

        () => { if (money >= upgradePrices.expand && upgrades.expandCount < upgradeLimits.expand) { money -= upgradePrices.expand; upgrades.expandCount++; rows++; generateTiles(); } },

        () => { if (!upgrades.autoPlant && money >= upgradePrices.autoPlant) { money -= upgradePrices.autoPlant; upgrades.autoPlant = true; } },

        () => { if (!upgrades.autoTransport && money >= upgradePrices.autoTransport) { money -= upgradePrices.autoTransport; upgrades.autoTransport = true; } }

      ][i]();

    }

  }

}

function drawWeatherHelp() {

  fill(255);

  stroke(0);

  rect(50, 50, 500, 500, 10);

  noStroke();

  fill(0);

  textSize(13);

  textAlign(LEFT, TOP);

  text(

    "📖 Guia de Eventos Climáticos\n\n" +

    "☀️ Seca:\n" +
    "Crescimento muito mais lento. Mesmo regiões naturalmente úmidas, como o litoral do Paraná, podem passar por períodos de estiagem. A falta de chuva prejudica o crescimento das plantas e compromete diretamente a produção agrícola. Como aconteceu em agosto de 2024, quando o litoral registrou um déficit de 37,7 mm de chuva — menos da metade da média histórica —, afetando culturas como mandioca, banana e hortaliças. (Simepar, 2024).\n\n" +
    "⛈️ Chuva forte:\n" +
    "As plantações são destruídas! Não é possível plantar enquanto chover. Eventos como deslizamentos, enchentes e quedas de barreira fazem parte da realidade do litoral do Paraná. O excesso de chuva deixa o solo instável, provoca deslizamentos que bloqueiam estradas, atrasam entregas e impactam o produtor rural. (AEN, 2023; Emater, 2025).\n\n" +
    "🐛 Praga:\n" +
    "Quando aparecem lagartas na sua plantação, elas se alimentam das folhas e isso reduz o crescimento. O controle biológico com Bacillus thuringiensis ou baculovírus é indicado quando se detectam 5 a 7 lagartas por planta — técnica eficaz contra o mandarová. (Embrapa, 2015).\n\n" +
    "⏳ Duração dos eventos: Cerca de 30 segundos.\n" +
    "⌛ Tempo entre eventos: Cerca de 25 segundos.",
    60, 60, 480, 430

  );

  // Botão Sair exatamente na área do botão Clima

  fill(255, 100, 100);

  stroke(0);

  rect(20, height - 40, 80, 30, 5);

  noStroke();

  fill(0);

  textAlign(CENTER, CENTER);

  text("❌ Sair", 60, height - 25);

}

function handleWeatherEvents() {

  fill(255, 0, 0, 230);

  rect(20, 10, width - 40, 40, 8);

  fill(255);

  textSize(14);

  textAlign(CENTER, CENTER);

  if (weatherEventDuration > 0) {

    weatherEventDuration--;

    text(weatherMessage + " (" + Math.ceil(weatherEventDuration / 60) + "s)", width / 2, 30);

    if (weatherEventDuration === 0) {

      drought = false;

      flood = false;

      weatherMessage = "";

    }

  } else {

    fill(255, 255, 100, 230);

    rect(20, 10, width - 40, 40, 8);

    fill(0);

    text("☁ Próximo evento em " + Math.ceil(nextWeatherEventTimer / 60) + "s", width / 2, 30);

    nextWeatherEventTimer--;

    if (nextWeatherEventTimer <= 0) {

      let roll = random();

      if (roll < 0.5) {

        drought = true;

        weatherMessage = "☀️ Seca: Crescimento lento!";

      } else {

        flood = true;

        weatherMessage = "⛈️ Chuva forte: Plantas destruídas!";

        for (let t of tiles) { t.state = "empty"; t.growth = 0; }

      }

      weatherEventDuration = 1800;

      nextWeatherEventTimer = 1500;

    }

  }

}

function keyPressed() {

  if (key === 'q' || key === 'Q') showShop = !showShop;

  if (key === 'w' || key === 'W') upgrades.autoTransport = false;

  if (key === 'a' || key === 'A') if (!truckMoving && transportCooldown === 0) startTruck();

  if (key === 'z' || key === 'Z') showWeatherHelp = !showWeatherHelp;

}

function autoPlant() {

  for (let t of tiles) {

    if (t.state === "empty" && !flood) {

      t.state = "growing";

      t.growth = 0;

    }

  }

}

function countReadyCrops() {

  return tiles.filter(t => t.state === "ready").length;

}

function mousePressed() {

  if (gameState === "start") { gameState = "story"; storyStep = 0; showPCWarning = false; return; }

  if (gameState === "story") { gameState = "game"; return; }

  if (gameState === "victory") { storyStep++; return; }

  if (gameState === "credits") { creditsStep++; return; }

  if (gameState === "references") { resetGame(); return; }

  if (showWeatherHelp) {

  // Botão Sair fica exatamente na área do botão Clima

  if (mouseX > 20 && mouseX < 100 && mouseY > height - 40 && mouseY < height - 10) {

    showWeatherHelp = false;

    return;

  }

}

  if (showShop) {

  // Botão Sair da Loja (fica em cima do botão Loja)

  if (mouseX > 20 && mouseX < 100 && mouseY > height - 80 && mouseY < height - 50) {

    showShop = false;

    return;

  }

  handleShopClick(mouseX, mouseY);

  return;

}

  if (mouseX > 20 && mouseX < 100 && mouseY > height - 80 && mouseY < height - 50) { showShop = true; return; }

  if (mouseX > 20 && mouseX < 100 && mouseY > height - 40 && mouseY < height - 10) { showWeatherHelp = true; return; }

  for (let t of tiles) if (t.clicked(mouseX, mouseY)) break;

}

function resetGame() {

  rows = 3;

  cols = 5;

  money = 0;

  growthRate = 0.01;

  transportCooldown = 0;

  cityStock = 0;

  truckMoving = false;

  upgrades = { autoPlant: false, autoTransport: false, expandCount: 0, valueMultiplier: 1 };

  upgradePrices = { value: 1000, expand: 1500, autoPlant: 2000, autoTransport: 3000 };

  progress = 0;

  truckX = width + 80;

  generateTiles();

  gameState = "start";

  showPCWarning = true;

}

function drawVictoryScreen() {

  background(180, 230, 180);

  fill(0);

  textSize(20);

  textAlign(CENTER, CENTER);

  if (storyStep === 0) {

    text("🏆 Vitória!", width / 2, 100);

    text("Você enfrentou secas, chuvas e pragas...", width / 2, 140);

    text("Mas com coragem, sua fazenda prosperou!", width / 2, 180);

    text("Clique para ver os créditos.", width / 2, 230);

  } else {

    gameState = "credits";

    creditsStep = 0;

  }

}

function drawCreditsScreen() {

  background(200, 220, 255);

  fill(0);

  textSize(18);

  textAlign(CENTER, CENTER);

  if (creditsStep === 0) {

    text("🎉 Créditos 🎉", width / 2, 80);

    textSize(16);

    text("Criação e Programação: Gustavo Spanholi", width / 2, 140);

    text("Agradecimento especial: Minha professora ❤️", width / 2, 180);

    text("Design: Unicode + Criatividade 😄", width / 2, 220);

    text("Inspiração: As aulas e dedicação! 🙌", width / 2, 260);

    text("Clique para ver Referências.", width / 2, 320);

  } else {

    gameState = "references";

  }

}

function drawReferencesScreen() {

  background(240);

  fill(0);

  textSize(13);

  textAlign(LEFT, TOP);

  text(

    "📚 Referências Bibliográficas\n\n" +

    "EMBRAPA – Empresa Brasileira de Pesquisa Agropecuária.\n" +

    "Pragas da mandioca: Manejo e controle da lagarta mandarová (Erinnyis ello). Cruz das Almas, BA: Embrapa Mandioca e Fruticultura, atualizado em 2025. Disponível em: https://www.embrapa.br/mandioca-e-fruticultura. Acesso em 15/06/2025\n\n" +

    "AEN – Agência Estadual de Notícias do Paraná.\n" +

    "Litoral do Paraná registra chuvas intensas, enchentes e deslizamentos entre fevereiro e abril de 2025, causando prejuízos na agricultura. Curitiba, PR: AEN-PR, 2025. Disponível em: https://www.aen.pr.gov.br. Acesso em 13/06/2025\n\n" +

    "IDR-Paraná – Instituto de Desenvolvimento Rural do Paraná.\n" +

    "Boletim Agrometeorológico de agosto de 2024. Déficit hídrico impacta culturas no litoral do Paraná. Curitiba, PR: IDR-Paraná/Simepar, 2024. Disponível em: https://www.idrparana.pr.gov.br. Acesso em 10/06/2025\n\n" +

    "Clique para reiniciar o jogo.", 50, 60, 500, 400

  );

}